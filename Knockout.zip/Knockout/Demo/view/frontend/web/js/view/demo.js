define([
   'ko',
   'uiComponent',
   'mage/url',
   'mage/storage',
   'jquery',
], function (ko, Component, urlBuilder,storage,jQuery) {
   'use strict';
   var id=1;
 
   return Component.extend({
 
       defaults: {
           template: 'Knockout_Demo/test',
       },
 
       productList: ko.observableArray([]),
 
       getProduct: function () {
           var self = this;
           var serviceUrl = urlBuilder.build('knockout/test/product?id='+id);
           id ++;
           return storage.post(
               serviceUrl,
               ''
           ).done(
               function (response) {
                    self.productList.push(JSON.parse(response));
               }
           ).fail(
               function (response) {
                   alert(response);
               }
           );
       },

       removeProduct: function(data,event){
          var event_id = event.target.id;
          jQuery('#'+event_id).closest('tr').remove();
       },

       decreaseQty : function(data,event){
          var event_id = event.target.id;
          var oldVal = jQuery('#'+event_id).closest('tr').find("input.qty").val();
          if (parseFloat(oldVal) >= 2) {
            var newVal = parseFloat(oldVal) - 1;
            jQuery('#'+event_id).closest('tr').find("input.qty").val(newVal);
          }
       },
       
       increaseQty : function(data,event){
          var event_id = event.target.id;
          var oldVal = jQuery('#'+event_id).closest('tr').find("input.qty").val();
          if (parseFloat(oldVal) >= 1) {
            var newVal = parseFloat(oldVal) + 1;
            jQuery('#'+event_id).closest('tr').find("input.qty").val(newVal);
          }
       },

       addToCart : function(){
          var self = this;
          var object = self.productList._latestValue;
          // var Qty = jQuery("input.qty").val();
          // console.log(Qty);
          var product_entity = jQuery.map(object, function(product) {
              return product.entity_id;
          });
          //console.log(product_entity);
          jQuery.ajax({
              url: urlBuilder.build('knockout/test/addtocart'),
              data: {'product_entity' : product_entity},
              type: 'post',
              dataType: 'json',
              success: function (res) {
                  console.log(res);
              }
          });  
       },

       removeAll : function(){
          var self = this;
          self.productList.removeAll();
       },
   });
});