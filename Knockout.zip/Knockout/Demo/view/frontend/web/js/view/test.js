define([
   'ko',
   'uiComponent',
   'mage/url',
   'mage/storage',
   'jquery',
], function (ko, Component, urlBuilder,storage,jQuery) {
   'use strict';
   var id=1;

   return Component.extend({
 
      defaults: {
        template: 'Knockout_Demo/test',
      },

      productList : ko.observableArray([]),

      initialize: function () {
        this._super();
      },

      getProduct: function () {
         var self = this;
         var serviceUrl = urlBuilder.build('knockout/test/product?id='+id);
         id ++;
         return storage.post(
             serviceUrl,
             ''
         ).done(
             function (response) {
                self.productList.push(JSON.parse(response));
             }
         ).fail(
             function (response) {
                 alert(response);
             }
         );
      },

      decreaseQty : function(data,event){
        var event_id = event.target.id;
        var oldVal = jQuery('#'+event_id).closest('tr').find("input.qty").val();
        if (parseFloat(oldVal) >= 2) {
          var newVal = parseFloat(oldVal) - 1;
          jQuery('#'+event_id).closest('tr').find("input.qty").val(newVal);
        }
      },

      increaseQty : function(data,event){
        var event_id = event.target.id;
        var oldVal = jQuery('#'+event_id).closest('tr').find("input.qty").val();
        if (parseFloat(oldVal) >= 1) {
          var newVal = parseFloat(oldVal) + 1;
          jQuery('#'+event_id).closest('tr').find("input.qty").val(newVal);
        }
      },

      addToCart : function(){
        var self = this;
        var object = self.productList._latestValue;
        
        var product_entity = jQuery.map(object, function(product) {
          if(product.entity_id){
            var qty = jQuery('#'+product.entity_id).closest('tr').find("input.qty").val();
            product['qty'] = qty;
            return product;
          }
        }); 
        
        var product_id = jQuery.map(product_entity, function(product) {
            return product.entity_id;
        });
        var test = {};
        var product_qty = jQuery.map(product_entity, function(product,i) {
            test[product.entity_id] = product.qty;
            return test;
        });
        
        jQuery.ajax({
            url: urlBuilder.build('knockout/test/addtocart'),
            data: {'product_entity' : product_id , 'product_qty' : product_qty[0]},
            type: 'post',
            dataType: 'json',
            success: function (res) {
                console.log(res);
            }
        });  
      },

      removeAll : function(){
        var self = this;
        self.productList.removeAll();
      },
   });
});